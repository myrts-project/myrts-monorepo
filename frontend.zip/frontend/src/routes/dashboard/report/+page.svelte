<script lang="ts">
	import Layout from '$lib/components/layout/Layout.svelte';
	import Maintenance from '$lib/components/ui/Maintenance.svelte';
</script>

<Layout title="Report(Analisis)" subtitle="Laporan analisis">
	<Maintenance />
</Layout>
