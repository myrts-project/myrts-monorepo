<script lang="ts">
	import Layout from '$lib/components/layout/Layout.svelte';
	import Maintenance from '$lib/components/ui/Maintenance.svelte';
</script>

<Layout title="Streaming" subtitle="Laporan Streaming">
	<Maintenance />
</Layout>
