<script lang="ts">
	import DashboardInner from '$lib/components/layout/DashboardInner.svelte';
</script>

<DashboardInner title="Streaming" subtitle="On Going Streaming">
	<div class="w-full flex-1 bg-white p-4 overflow-hidden flex items-center justify-center">
		<h1 class="text-gray-400 text-xl text-center font-semibold">Tidak ada streaming</h1>
	</div>
</DashboardInner>
