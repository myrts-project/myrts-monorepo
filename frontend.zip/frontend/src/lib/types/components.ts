export type NameValue<T> = {
	name: string;
	value: T;
};
