<script lang="ts">
	//
</script>

<td>
	<slot />
</td>
