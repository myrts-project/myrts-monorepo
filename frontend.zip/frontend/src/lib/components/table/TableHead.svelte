<script lang="ts">
	//
</script>

<thead class="border-b bg-gray-200 rounded-t-md">
	<tr>
		<slot />
	</tr>
</thead>
