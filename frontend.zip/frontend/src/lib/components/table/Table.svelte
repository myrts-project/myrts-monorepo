<script lang="ts">
	//
</script>

<table class="min-w-full">
	<slot />
</table>
