<script lang="ts">
	//
</script>

<tbody>
	<slot />
</tbody>
