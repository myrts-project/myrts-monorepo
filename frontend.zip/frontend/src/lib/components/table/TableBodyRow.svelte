<script lang="ts">
	//
</script>

<tr>
	<slot />
</tr>
