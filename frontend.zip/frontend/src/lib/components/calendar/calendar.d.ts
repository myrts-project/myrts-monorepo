declare module '@event-calendar/list' {}
