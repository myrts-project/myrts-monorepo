<svg {...$$props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"
	><path d="M 10 6 L 10 26 L 12 26 L 12 6 Z M 20 6 L 20 26 L 22 26 L 22 6 Z" /></svg
>
