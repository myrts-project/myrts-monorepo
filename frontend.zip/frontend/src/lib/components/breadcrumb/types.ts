export type BreadCrumbItem = {
	name: string;
	url: string;
};
