declare module '@event-calendar/core';
