declare module '@event-calendar/time-grid';
