declare module '@event-calendar/day-grid';
