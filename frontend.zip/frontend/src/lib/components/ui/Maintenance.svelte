<div class="w-full justify-center items-center">
	<div class="p-8 rounded-md shadow-lg">
		<h1 class="text-4xl text-gray-400 text-center">MAINTENANCE</h1>
	</div>
</div>
