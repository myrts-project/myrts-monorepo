// The url of the api.
export const API_URL = 'https://api.myrts.id';
// The url of the stream.
export const STREAM_URL = 'wss://api.myrts.id/ws';
